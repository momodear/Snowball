import stanfordnlp

English_pipline = stanfordnlp.Pipeline()
f = open('Splitted_Sentences.txt', 'r')
f_out = open('Tagged_Sentences.txt', 'w')


for EveryLine in f.readlines():
    TemporarySvaedLine = []
    nlp = English_pipline
    assecced_document = nlp(EveryLine)

    for Everysentence in assecced_document.sentences:
        l = []
        l_original = []

        for Index_Unused, deep_edge_layer in enumerate(Everysentence.dependencies):
            l.append(deep_edge_layer[2].text)
            l_original.append(deep_edge_layer[2].text)


        for Word_Index_Number, deep_edge_layer in enumerate(Everysentence.dependencies): # Check the subject of the sentence
            i = Word_Index_Number
            n = deep_edge_layer

            if 'subj' in deep_edge_layer[1]:
                index_sub = nlp.subject_processors(Word_Index_Number,Everysentence)
                index_endsub = nlp.endsubject_processors(Word_Index_Number,Everysentence)
                m = deep_edge_layer[2].governor - 1
                if index_sub == 1:
                    l[i - 1] = '<SUBJ>' + l_original[Word_Index_Number - 1]
                if index_sub == 2:
                    l[Word_Index_Number] = '<SUBJ>' + l_original[Word_Index_Number]
                if index_endsub == 3:
                    l[Word_Index_Number + 1] = l_original[Word_Index_Number + 1] + '</SUBJ>'
                if index_endsub == 4:
                    l[Word_Index_Number] = l[Word_Index_Number] + '</SUBJ>'
                j = m

                if 'V' in Everysentence.dependencies[j][2].upos:
                    v_index = nlp.verb_provessor(j, Everysentence)
                    v_end_index = nlp.verb_provessor_end(j, Everysentence)

                    if v_index == 1:
                        l[j - 1] = l_original[j - 1]
                    if v_index == 2:
                        l[j] = l_original[j]
                    if v_end_index == 3:
                        l[j + 1] = l_original[j + 1]
                    if v_end_index == 4:
                        l[j] = l[j]

                elif 'N' in Everysentence.dependencies[j][2].upos:
                    n_index = nlp.noun_provessor(j, Everysentence)
                    n_end_index = nlp.end_noun_provessor(j, Everysentence)
                    if n_index == 1:
                        l[j - 1] = '<OBJ>' + l_original[j - 1]
                    if n_index == 2:
                        l[j] = '<OBJ>' + l_original[j]
                    if n_end_index == 3:
                        l[j + 1] = l_original[j + 1] + '</OBJ>'
                    if n_end_index == 4:
                        l[j] = l[j] + '</OBJ>'


            elif 'obj' in deep_edge_layer[1]:
                index_obj = nlp.object_processors(Word_Index_Number,Everysentence)
                end_index_obj = nlp.end_object_processors(Word_Index_Number,Everysentence)
                m = deep_edge_layer[2].governor - 1
                if index_obj == 1:
                    l[Word_Index_Number - 1] = '<OBJ>' + l_original[Word_Index_Number - 1]
                if index_obj == 2:
                    l[Word_Index_Number] = '<OBJ>' + l_original[Word_Index_Number]
                if end_index_obj == 3:
                    l[Word_Index_Number + 1] = l_original[Word_Index_Number + 1] + '</OBJ>'
                if end_index_obj == 4:
                    l[Word_Index_Number] = l[Word_Index_Number] + '</OBJ>'

                j = m
                if 'V' in Everysentence.dependencies[j][2].upos:
                    v_index = nlp.verb_provessor(j,Everysentence)
                    v_end_index=nlp.verb_provessor_end(j,Everysentence)

                    if v_index==1:
                        l[j - 1] = l_original[j - 1]
                    if v_index == 2:
                        l[j] = l_original[j]
                    if v_end_index == 3:
                        l[j + 1] = l_original[j + 1]
                    if v_end_index == 4:
                        l[j] = l[j]

                elif 'N' in Everysentence.dependencies[j][2].upos:
                    n_index = nlp.noun_provessor(j,Everysentence)
                    n_end_index = nlp.end_noun_provessor(j, Everysentence)
                    if n_index == 1:
                        l[j - 1] = '<SUBJ>' + l_original[j - 1]
                    if n_index == 2:
                        l[j] = '<SUBJ>' + l_original[j]
                    if n_end_index == 3:
                        l[j + 1] = l_original[j + 1] + '</SUBJ>'
                    if n_end_index == 4:
                        l[j] = l[j] + '</SUBJ>'

            elif 'cop' in deep_edge_layer[1]:
                pre_index = nlp.PRE_processors(Word_Index_Number,Everysentence)
                end_pre_index=nlp.PRE_end_processors(Word_Index_Number,Everysentence)
                n = deep_edge_layer[2].governor - 1
                if pre_index == 1:
                    l[Word_Index_Number - 1] = l_original[Word_Index_Number - 1]
                if pre_index == 2:
                    l[Word_Index_Number] = l_original[Word_Index_Number]
                if end_pre_index == 3:
                    l[Word_Index_Number + 1] = l_original[Word_Index_Number + 1]
                if end_pre_index == 4:
                    l[Word_Index_Number] = l[Word_Index_Number]

                j = n
                if 'subj' in Everysentence.dependencies[j][1]:
                    index_sub = nlp.subject_processors(Word_Index_Number,Everysentence)
                    index_endsub = nlp.endsubject_processors(Word_Index_Number,Everysentence)
                    if index_sub == 1:
                        l[i - 1] = '<SUBJ>' + l_original[Word_Index_Number - 1]
                    if index_sub == 2:
                        l[Word_Index_Number] = '<SUBJ>' + l_original[Word_Index_Number]
                    if index_endsub == 3:
                        l[Word_Index_Number + 1] = l_original[Word_Index_Number + 1] + '</SUBJ>'
                    if index_endsub == 4:
                        l[Word_Index_Number] = l[Word_Index_Number] + '</SUBJ>'

                elif 'obj' in Everysentence.dependencies[j][2].upos:
                    index_obj = nlp.object_processors(Word_Index_Number,Everysentence)
                    end_index_obj = nlp.end_object_processors(Word_Index_Number,Everysentence)
                    if index_obj == 1:
                        l[Word_Index_Number - 1] = '<OBJ>' + l_original[Word_Index_Number - 1]
                    if index_obj == 2:
                        l[Word_Index_Number] = '<OBJ>' + l_original[Word_Index_Number]
                    if end_index_obj == 3:
                        l[Word_Index_Number + 1] = l_original[Word_Index_Number + 1] + '</OBJ>'
                    if end_index_obj == 4:
                        l[Word_Index_Number] = l[Word_Index_Number] + '</OBJ>'



        TemporarySvaedLine += l

    FinalDocument = TemporarySvaedLine
    f_out.write(' '.join(FinalDocument))
    f_out.write('\n')
    print(' '.join(FinalDocument))

